  
import os
import setuptools
#os.system("pip install Django==3.0.7")
#os.system("pip install pyrebase")
#os.system("pip install beautifulsoup4")
#os.chdir("cpanel")
#os.system("python manage.py runserver")

if __name__ == "__main__":
    setuptools.setup()
    #os.chdir("cpanel")
    #os.system("python manage.py runserver")