
def myConfig():
    config = {
        "apiKey": "AIzaSyBkIAGYXQ-yVBkoRqXKuBKGuXPUpNzAP7g",
        "authDomain": "empty-my-fridge-ff73c.firebaseapp.com",
        "databaseURL": "https://empty-my-fridge-ff73c.firebaseio.com",
        "projectId": "empty-my-fridge-ff73c",
        "storageBucket": "empty-my-fridge-ff73c.appspot.com",
        "messagingSenderId": "904741248232",
        "appId": "1:904741248232:web:33ba3b5e81be538db2fd5d",
        "measurementId": "G-9SLJ34LP0M"
        
        """
        'apiKey': "AIzaSyDMlZ3DzGdgJ7aQc3iUl-S5lG6GpWMhCOw",
        'authDomain': "empty-my-fridge-6197d.firebaseapp.com",
        'databaseURL': "https://empty-my-fridge-6197d.firebaseio.com",
        'projectId': "empty-my-fridge-6197d",
        'storageBucket': "empty-my-fridge-6197d.appspot.com",
        'messagingSenderId': "210802633597",
        'appId': "1:210802633597:web:239240de47cbf5e2b6ba14",
        'measurementId': "G-26T7SBKJCX",
        """
    }
    return config
